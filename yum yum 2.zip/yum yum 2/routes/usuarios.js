const express = require('express');
const router = express.Router();

// Obtener todos los usuarios
router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM usuarios', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});

// Agregar un nuevo usuario
router.post('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO usuarios SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Usuario agregado correctamente!');
        });
    });
});

// Actualizar un usuario
router.put('/:id', (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('UPDATE usuarios SET ? WHERE id = ?', [req.body, id], (err, result) => {
            if (err) return res.status(500).send(err);
            if (result.affectedRows === 0) {
                return res.status(404).send('Usuario no encontrado');
            }
            res.send('Usuario actualizado correctamente!');
        });
    });
});

// Eliminar un usuario
router.delete('/:id', (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('DELETE FROM usuarios WHERE id = ?', [id], (err, result) => {
            if (err) return res.status(500).send(err);
            if (result.affectedRows === 0) {
                return res.status(404).send('Usuario no encontrado');
            }
            res.send('Usuario eliminado correctamente!');
        });
    });
});

module.exports = router;
