const express = require('express');
const router = express.Router();

// Obtener todos los ingredientes
router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM ingredientes', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});

// Agregar un nuevo ingrediente
router.post('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO ingredientes SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Ingrediente agregado correctamente!');
        });
    });
});

// Actualizar un ingrediente
router.put('/:id', (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('UPDATE ingredientes SET ? WHERE id = ?', [req.body, id], (err, result) => {
            if (err) return res.status(500).send(err);
            if (result.affectedRows === 0) {
                return res.status(404).send('Ingrediente no encontrado');
            }
            res.send('Ingrediente actualizado correctamente!');
        });
    });
});

// Eliminar un ingrediente
router.delete('/:id', (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('DELETE FROM ingredientes WHERE id = ?', [id], (err, result) => {
            if (err) return res.status(500).send(err);
            if (result.affectedRows === 0) {
                return res.status(404).send('Ingrediente no encontrado');
            }
            res.send('Ingrediente eliminado correctamente!');
        });
    });
});

module.exports = router;
