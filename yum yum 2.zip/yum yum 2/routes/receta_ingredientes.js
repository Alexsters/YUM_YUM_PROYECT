const express = require('express');
const router = express.Router();
// Obtener todas las relaciones receta-ingrediente
router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM receta_ingrediente', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});
// Agregar una nueva relación receta-ingrediente
router.post('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO receta_ingrediente SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Relación receta-ingrediente agregada correctamente!');
        });
    });
});
module.exports = router;