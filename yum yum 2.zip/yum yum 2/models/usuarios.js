const db = require('../db'); // Asegúrate de tener un archivo db.js que exporte la conexión a la base de datos
class Usuario {
    static async crear(usuario) {
        const query = 'INSERT INTO usuarios (nombre1, nombre2, apellido1, apellido2, edad, email, nacionalidad) VALUES (?, ?, ?, ?, ?, ?, ?)';
        const result = await db.query(query, [usuario.nombre1, usuario.nombre2, usuario.apellido1, usuario.apellido2, usuario.edad, usuario.email, usuario.nacionalidad]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM usuarios';
        const result = await db.query(query);
        return result;
    }
    static async actualizar(id, usuario) {
        const query = 'UPDATE usuarios SET nombre1 = ?, nombre2 = ?, apellido1 = ?, apellido2 = ?, edad = ?, email = ?, nacionalidad = ? WHERE id = ?';
        await db.query(query, [usuario.nombre1, usuario.nombre2, usuario.apellido1, usuario.apellido2, usuario.edad, usuario.email, usuario.nacionalidad, id]);
    }
    static async eliminar(id) {
        const query = 'DELETE FROM usuarios WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = Usuario;