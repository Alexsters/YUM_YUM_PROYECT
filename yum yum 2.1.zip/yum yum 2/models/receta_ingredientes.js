const db = require('../db');
class RecetaIngrediente {
    static async crear(recetaIngrediente) {
        const query = 'INSERT INTO recetas_ingredientes (receta_id, ingrediente_id, cantidad) VALUES (?, ?, ?)';
        const result = await db.query(query, [recetaIngrediente.receta_id, recetaIngrediente.ingrediente_id, recetaIngrediente.cantidad]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM recetas_ingredientes';
        const result = await db.query(query);
        return result;
    }
    static async eliminar(id) {
        const query = 'DELETE FROM recetas_ingredientes WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = RecetaIngrediente;