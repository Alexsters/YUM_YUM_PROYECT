const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM comentarios', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});

router.post('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO comentarios SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Comentario agregado correctamente!');
        });
    });
});
module.exports = router;