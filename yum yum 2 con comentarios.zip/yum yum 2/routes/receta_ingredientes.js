const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM receta_ingrediente', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});

router.post('/', (req, res) => {
    const { receta_id, ingrediente_id, cantidad } = req.body;
    if (!receta_id || !ingrediente_id || !cantidad) {
        return res.status(400).send('Faltan campos requeridos');
    }
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO receta_ingrediente SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Relación receta-ingrediente agregada correctamente!');
        });
    });
});
module.exports = router;
