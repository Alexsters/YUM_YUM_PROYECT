const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM comentarios', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});

router.post('/', (req, res) => {
    const { receta_id, usuario_id, comentario } = req.body;
    if (!receta_id || !usuario_id || !comentario) {
        return res.status(400).send('Faltan campos requeridos');
    }
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO comentarios SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Comentario agregado correctamente!');
        });
    });
});
module.exports = router;
