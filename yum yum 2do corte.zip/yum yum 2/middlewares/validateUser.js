const validateUser = (req, res, next) => {
    const { nombre1, apellido1, email, edad, nacionalidad, contraseña } = req.body;
    
    // Check all required fields
    if (!nombre1 || !apellido1 || !email || !edad || !nacionalidad || !contraseña) {
        return res.status(400).json({
            success: false,
            message: 'Faltan campos requeridos: nombre1, apellido1, email, edad, nacionalidad, contraseña'
        });
    }

    // Validate age is positive number
    if (typeof edad !== 'number' || edad < 1) {
        return res.status(400).json({
            success: false,
            message: 'La edad debe ser un número positivo'
        });
    }

    
    if (!email.includes('@') || !email.includes('.')) {
        return res.status(400).json({
            success: false,
            message: 'Formato de email inválido'
        });
    }

    // Validate password strength
    if (contraseña.length < 8) {
        return res.status(400).json({
            success: false,
            message: 'La contraseña debe tener al menos 8 caracteres'
        });
    }

    next();
};

module.exports = validateUser;
