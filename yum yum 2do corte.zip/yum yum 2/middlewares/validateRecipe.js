const validateRecipe = (req, res, next) => {
    const { title, ingredients } = req.body; // Adjust based on actual required fields

    if (!title || !ingredients) {
        return res.status(400).json({
            success: false,
            message: 'Title and ingredients are required'
        });
    }

    next();
};

module.exports = validateRecipe;
