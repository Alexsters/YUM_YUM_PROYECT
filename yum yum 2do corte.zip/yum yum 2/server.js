const express = require('express');
const mysql = require('mysql');
const myconn = require('express-myconnection');
const app = express();
const usuariosRoutes = require('./controllers/usuarios');
const recetasRoutes = require('./controllers/recetas');
const ingredientesRoutes = require('./controllers/ingredientes');
const comentariosRoutes = require('./controllers/comentarios');
const recetaIngredientesRoutes = require('./controllers/receta_ingredientes'); // Asegúrate de que el nombre sea correcto
app.set('port', process.env.PORT || 3000);
const dbOptions = {
    host: '127.0.0.1',
    user: 'root',
    password: '',
    port: 3306,
    database: 'yum_yum_db_proyect'
};
// MIDDLEWARES
app.use(myconn(mysql, dbOptions, 'single'));
app.use(express.json());
// RUTAS
app.get('/', (req, res) => {
    res.send('¡Bienvenido a la API de Yum Yum!');
});
app.use('/api/usuarios', usuariosRoutes);
app.use('/api/recetas', recetasRoutes);
app.use('/api/ingredientes', ingredientesRoutes);
app.use('/api/comentarios', comentariosRoutes);
app.use('/api/receta-ingredientes', recetaIngredientesRoutes);
// SERVER RUNNING
app.listen(app.get('port'), () => {
    console.log('Servidor en http://localhost:' + app.get('port'));
});