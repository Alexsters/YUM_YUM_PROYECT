const db = require('../db');
class Ingrediente {
    static async crear(ingrediente) {
        const query = 'INSERT INTO ingredientes (nombre) VALUES (?)';
        const result = await db.query(query, [ingrediente.nombre]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM ingredientes';
        const result = await db.query(query);
        return result;
    }
    static async actualizar(id, ingrediente) {
        const query = 'UPDATE ingredientes SET nombre = ? WHERE id = ?';
        await db.query(query, [ingrediente.nombre, id]);
    }
    static async eliminar(id) {
        const query = 'DELETE FROM ingredientes WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = Ingrediente;