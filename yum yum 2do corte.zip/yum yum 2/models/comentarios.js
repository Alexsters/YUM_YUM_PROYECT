const db = require('../db');
class Comentario {
    static async crear(comentario) {
        const query = 'INSERT INTO comentarios (receta_id, usuario_id, comentario) VALUES (?, ?, ?)';
        const result = await db.query(query, [comentario.receta_id, comentario.usuario_id, comentario.comentario]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = `
            SELECT 
                c.id,
                c.comentario,
                r.titulo AS receta,
                u.nombre1 AS usuario
            FROM 
                comentarios c
            JOIN 
                recetas r ON c.receta_id = r.id
            JOIN 
                usuarios u ON c.usuario_id = u.id
        `;
        const result = await db.query(query);
        return result;
    }
    static async actualizar(id, comentario) {
        const query = 'UPDATE comentarios SET receta_id = ?, usuario_id = ?, comentario = ? WHERE id = ?';
        await db.query(query, [comentario.receta_id, comentario.usuario_id, comentario.comentario, id]);
    }
    static async eliminar(id) {
        const query = 'DELETE FROM comentarios WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = Comentario;