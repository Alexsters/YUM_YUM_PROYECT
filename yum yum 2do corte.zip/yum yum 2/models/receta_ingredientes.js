const db = require('../db');
class RecetaIngrediente {
    static async crear(recetaIngrediente) {
        const query = 'INSERT INTO recetas_ingredientes (receta_id, ingrediente_id, cantidad) VALUES (?, ?, ?)';
        const result = await db.query(query, [recetaIngrediente.receta_id, recetaIngrediente.ingrediente_id, recetaIngrediente.cantidad]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM recetas_ingredientes';
        const result = await db.query(query);
        return result;
    }
    static async obtenerRelaciones() {
        const query = `
            SELECT 
                ri.id,
                r.titulo AS receta,
                i.nombre AS ingrediente,
                ri.cantidad
            FROM 
                recetas_ingredientes ri
            JOIN 
                recetas r ON ri.receta_id = r.id
            JOIN 
                ingredientes i ON ri.ingrediente_id = i.id
        `;
        const result = await db.query(query);
        return result;
    }
    
    static async eliminar(id) {
        const query = 'DELETE FROM recetas_ingredientes WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = RecetaIngrediente;