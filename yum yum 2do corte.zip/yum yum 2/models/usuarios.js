const db = require('../db');
const bcrypt = require('bcrypt');
const saltRounds = 10; //seguridad

class Usuario {
    static async crear(usuario) {
        // verificar si el usuario ya existexd
        const hashedPassword = await bcrypt.hash(usuario.contraseña, saltRounds);
        
        const query = 'INSERT INTO usuarios (nombre1, nombre2, apellido1, apellido2, edad, email, nacionalidad, contraseña) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
        const result = await db.query(query, [
            usuario.nombre1,
            usuario.nombre2,
            usuario.apellido1,
            usuario.apellido2,
            usuario.edad,
            usuario.email,
            usuario.nacionalidad,
            hashedPassword
        ]);
        return result.insertId;
    }

    static async obtenerTodos() {
        
        const query = 'SELECT id, nombre1, nombre2, apellido1, apellido2, edad, email, nacionalidad FROM usuarios';
        return await db.query(query);
    }

    static async actualizar(id, usuario) {
        let query, params;
        if (usuario.contraseña) {
           
            const hashedPassword = await bcrypt.hash(usuario.contraseña, saltRounds);
            query = 'UPDATE usuarios SET nombre1=?, nombre2=?, apellido1=?, apellido2=?, edad=?, email=?, nacionalidad=?, contraseña=? WHERE id=?';
            params = [
                usuario.nombre1,
                usuario.nombre2,
                usuario.apellido1,
                usuario.apellido2,
                usuario.edad,
                usuario.email,
                usuario.nacionalidad,
                hashedPassword,
                id
            ];
        } else {
            query = 'UPDATE usuarios SET nombre1=?, nombre2=?, apellido1=?, apellido2=?, edad=?, email=?, nacionalidad=? WHERE id=?';
            params = [
                usuario.nombre1,
                usuario.nombre2,
                usuario.apellido1,
                usuario.apellido2,
                usuario.edad,
                usuario.email,
                usuario.nacionalidad,
                id
            ];
        }
        await db.query(query, params);
    }

    static async eliminar(id) {
        await db.query('DELETE FROM usuarios WHERE id=?', [id]);
    }

    static async autenticar(email, contraseña) {
        const [user] = await db.query('SELECT * FROM usuarios WHERE email=?', [email]);
        
        if (!user) {
            throw new Error('Usuario no encontrado');
        }

        
        const match = await bcrypt.compare(contraseña, user.contraseña);
        if (!match) {
            throw new Error('Contraseña incorrecta');
        }

        //no devuelve contra
        return {
            id: user.id,
            nombre1: user.nombre1,
            email: user.email
        };
    }
}

module.exports = Usuario;
