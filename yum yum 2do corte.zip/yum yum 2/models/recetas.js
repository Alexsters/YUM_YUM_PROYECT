const db = require('../db');
class Receta {
    static async crear(receta) {
        const query = 'INSERT INTO recetas (usuario_id, titulo, descripcion, tiempo_preparacion, dificultad) VALUES (?, ?, ?, ?, ?)';
        const result = await db.query(query, [receta.usuario_id, receta.titulo, receta.descripcion, receta.tiempo_preparacion, receta.dificultad]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM recetas';
        const result = await db.query(query);
        return result;
    }
    static async actualizar(id, receta) {
        const query = 'UPDATE recetas SET usuario_id = ?, titulo = ?, descripcion = ?, tiempo_preparacion = ?, dificultad = ? WHERE id = ?';
        await db.query(query, [receta.usuario_id, receta.titulo, receta.descripcion, receta.tiempo_preparacion, receta.dificultad, id]);
    }
    static async eliminar(id) {
        const query = 'DELETE FROM recetas WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = Receta;