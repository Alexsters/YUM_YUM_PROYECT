const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM recetas_ingredientes', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});

router.get('/relaciones', async (req, res) => {
    try {
        const relaciones = await RecetaIngrediente.obtenerRelaciones();
        res.json(relaciones);
    } catch (error) {
        res.status(500).send('Error al obtener relaciones');
    }
});

router.post('/', async (req, res) => {
    const { receta_id, ingrediente_id, cantidad } = req.body;
    if (!receta_id || !ingrediente_id || !cantidad) {
        return res.status(400).send('Faltan campos requeridos');
    }
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO recetas_ingredientes SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Relación receta-ingrediente agregada correctamente!');
        });
    });
});
module.exports = router;
