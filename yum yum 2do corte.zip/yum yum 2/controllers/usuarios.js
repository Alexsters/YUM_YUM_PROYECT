const express = require('express');
const router = express.Router();
const Usuario = require('../models/usuarios');
const validateUser = require('../middlewares/validateUser');

// User authentication
router.post('/login', async (req, res) => {
    try {
        const { email, contraseña } = req.body;
        if (!email || !contraseña) {
            return res.status(400).json({
                success: false,
                message: 'Email y contraseña son requeridos'
            });
        }
        
        const user = await Usuario.autenticar(email, contraseña);
        res.json({
            success: true,
            message: 'Autenticación exitosa',
            data: {
                id: user.id,
                nombre1: user.nombre1,
                email: user.email
            }
        });
    } catch (error) {
        res.status(401).json({
            success: false,
            message: error.message
        });
    }
});

// Get all users (without sensitive data)
router.get('/', async (req, res) => {
    try {
        const users = await Usuario.obtenerTodos();
        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error al obtener usuarios'
        });
    }
});

// Create new user with password hashing
router.post('/', validateUser, async (req, res) => {
    try {
        const userId = await Usuario.crear(req.body);
        res.status(201).json({
            success: true,
            message: 'Usuario creado exitosamente',
            userId
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Update user (with optional password update)
router.put('/:id', validateUser, async (req, res) => {
    try {
        const { id } = req.params;
        await Usuario.actualizar(id, req.body);
        res.json({
            success: true,
            message: 'Usuario actualizado exitosamente'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Delete user
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await Usuario.eliminar(id);
        res.json({
            success: true,
            message: 'Usuario eliminado exitosamente'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error al eliminar usuario'
        });
    }
});

module.exports = router;
