const db = require('../db');
class Comentario {
    static async crear(comentario) {
        const query = 'INSERT INTO comentarios (receta_id, usuario_id, comentario) VALUES (?, ?, ?)';
        const result = await db.query(query, [comentario.receta_id, comentario.usuario_id, comentario.comentario]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM comentarios';
        const result = await db.query(query);
        return result;
    }
    static async actualizar(id, comentario) {
        const query = 'UPDATE comentarios SET receta_id = ?, usuario_id = ?, comentario = ? WHERE id = ?';
        await db.query(query, [comentario.receta_id, comentario.usuario_id, comentario.comentario, id]);
    }
    static async eliminar(id) {
        const query = 'DELETE FROM comentarios WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = Comentario;

const db = require('../db');
class Ingrediente {
    static async crear(ingrediente) {
        const query = 'INSERT INTO ingredientes (nombre) VALUES (?)';
        const result = await db.query(query, [ingrediente.nombre]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM ingredientes';
        const result = await db.query(query);
        return result;
    }
    static async actualizar(id, ingrediente) {
        const query = 'UPDATE ingredientes SET nombre = ? WHERE id = ?';
        await db.query(query, [ingrediente.nombre, id]);
    }
    static async eliminar(id) {
        const query = 'DELETE FROM ingredientes WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = Ingrediente;

const db = require('../db');
class Receta {
    static async crear(receta) {
        const query = 'INSERT INTO recetas (usuario_id, titulo, descripcion, tiempo_preparacion, dificultad) VALUES (?, ?, ?, ?, ?)';
        const result = await db.query(query, [receta.usuario_id, receta.titulo, receta.descripcion, receta.tiempo_preparacion, receta.dificultad]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM recetas';
        const result = await db.query(query);
        return result;
    }
    static async actualizar(id, receta) {
        const query = 'UPDATE recetas SET usuario_id = ?, titulo = ?, descripcion = ?, tiempo_preparacion = ?, dificultad = ? WHERE id = ?';
        await db.query(query, [receta.usuario_id, receta.titulo, receta.descripcion, receta.tiempo_preparacion, receta.dificultad, id]);
    }
    static async eliminar(id) {
        const query = 'DELETE FROM recetas WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = Receta;

const db = require('../db');
class RecetaIngrediente {
    static async crear(recetaIngrediente) {
        const query = 'INSERT INTO recetas_ingredientes (receta_id, ingrediente_id, cantidad) VALUES (?, ?, ?)';
        const result = await db.query(query, [recetaIngrediente.receta_id, recetaIngrediente.ingrediente_id, recetaIngrediente.cantidad]);
        return result.insertId;
    }
    static async obtenerTodos() {
        const query = 'SELECT * FROM recetas_ingredientes';
        const result = await db.query(query);
        return result;
    }
    static async eliminar(id) {
        const query = 'DELETE FROM recetas_ingredientes WHERE id = ?';
        await db.query(query, [id]);
    }
}
module.exports = RecetaIngrediente;

const db = require('../db');
const bcrypt = require('bcrypt');
const saltRounds = 10; //seguridad

class Usuario {
    static async crear(usuario) {
        const hashedPassword = await bcrypt.hash(usuario.contraseña, saltRounds);
        
        const query = 'INSERT INTO usuarios (nombre1, nombre2, apellido1, apellido2, edad, email, nacionalidad, contraseña) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
        const result = await db.query(query, [
            usuario.nombre1,
            usuario.nombre2,
            usuario.apellido1,
            usuario.apellido2,
            usuario.edad,
            usuario.email,
            usuario.nacionalidad,
            hashedPassword
        ]);
        return result.insertId;
    }

    static async obtenerTodos() {
        const query = 'SELECT id, nombre1, nombre2, apellido1, apellido2, edad, email, nacionalidad FROM usuarios';
        return await db.query(query);
    }

    static async actualizar(id, usuario) {
        let query, params;
        if (usuario.contraseña) {
            const hashedPassword = await bcrypt.hash(usuario.contraseña, saltRounds);
            query = 'UPDATE usuarios SET nombre1=?, nombre2=?, apellido1=?, apellido2=?, edad=?, email=?, nacionalidad=?, contraseña=? WHERE id=?';
            params = [
                usuario.nombre1,
                usuario.nombre2,
                usuario.apellido1,
                usuario.apellido2,
                usuario.edad,
                usuario.email,
                usuario.nacionalidad,
                hashedPassword,
                id
            ];
        } else {
            query = 'UPDATE usuarios SET nombre1=?, nombre2=?, apellido1=?, apellido2=?, edad=?, email=?, nacionalidad=? WHERE id=?';
            params = [
                usuario.nombre1,
                usuario.nombre2,
                usuario.apellido1,
                usuario.apellido2,
                usuario.edad,
                usuario.email,
                usuario.nacionalidad,
                id
            ];
        }
        await db.query(query, params);
    }

    static async eliminar(id) {
        await db.query('DELETE FROM usuarios WHERE id=?', [id]);
    }

    static async autenticar(email, contraseña) {
        const [user] = await db.query('SELECT * FROM usuarios WHERE email=?', [email]);
        
        if (!user) {
            throw new Error('Usuario no encontrado');
        }

        const match = await bcrypt.compare(contraseña, user.contraseña);
        if (!match) {
            throw new Error('Contraseña incorrecta');
        }

        return {
            id: user.id,
            nombre1: user.nombre1,
            email: user.email
        };
    }
}

module.exports = Usuario;
