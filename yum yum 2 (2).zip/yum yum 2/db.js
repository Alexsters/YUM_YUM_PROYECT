// db.js
const mysql = require('mysql');
const util = require('util');
const db = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root', // Cambia esto si usas otro usuario
    password: '', // Cambia esto si tu base de datos tiene una contraseña
    database: 'yum_yum_db_proyect'
});
// Conectar a la base de datos
db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos: ', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});
// Promisify para usar async/await
db.query = util.promisify(db.query);
module.exports = db;