const express = require('express');
const router = express.Router();


router.get('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('SELECT * FROM recetas', (err, rows) => {
            if (err) return res.status(500).send(err);
            res.json(rows);
        });
    });
});


router.post('/', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('INSERT INTO recetas SET ?', [req.body], (err) => {
            if (err) return res.status(500).send(err);
            res.send('Receta agregada correctamente!');
        });
    });
});

router.put('/:id', (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('UPDATE recetas SET ? WHERE id = ?', [req.body, id], (err, result) => {
            if (err) return res.status(500).send(err);
            if (result.affectedRows === 0) {
                return res.status(404).send('Receta no encontrada');
            }
            res.send('Receta actualizada correctamente!');
        });
    });
});


router.delete('/:id', (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        if (err) return res.status(500).send(err);
        conn.query('DELETE FROM recetas WHERE id = ?', [id], (err, result) => {
            if (err) return res.status(500).send(err);
            if (result.affectedRows === 0) {
                return res.status(404).send('Receta no encontrada');
            }
            res.send('Receta eliminada correctamente!');
        });
    });
});

module.exports = router;
